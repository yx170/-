/*
 * 初始化SWIPER，基于一些参数配置实现滑屏的效果
 * https://www.swiper.com.cn/api/
 */
var mySwiper = new Swiper('.swiper-container', {
    direction: 'vertical',
    loop: true,
    on: {
        init: function () {
            swiperAnimateCache(this);
            swiperAnimate(this);
        },
        slideChangeTransitionEnd: function () {
            swiperAnimate(this);
        }
    }
});